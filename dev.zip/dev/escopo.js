console.log("===Controlando Escopo===")
//alert(empresa);
//var empresa=null;

function teste(){
    company="Caelum"
    console.log(company);
}
teste();