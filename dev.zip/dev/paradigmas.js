console.log("===PARADIGMAS===");


//sintaxe literal
var empresa="Alura";
console.log(empresa,typeof(empresa),empresa.constructor);
//sintaxe OOP
var company=new String("Alura");
console.log(company,typeof(company),company.constructor);
console.dir(String.prototype);